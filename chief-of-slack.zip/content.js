// content.js — thin bridge between inject.js (page context) and side panel (via background.js)
console.log('[fslack] content.js bridge loaded', new Date().toISOString());

const FSLACK = 'fslack';

// Suppress "Could not establish connection" errors from orphaned content scripts
window.addEventListener('unhandledrejection', (e) => {
  if (e.reason?.message?.includes('Could not establish connection')) {
    e.preventDefault();
  }
});

// ── Inject page-context script ──
try {
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  script.onload = () => script.remove();
  (document.head || document.documentElement).appendChild(script);
} catch {
  throw new Error('FSlack: extension context invalidated, skipping.');
}

// ── Track inject.js ready state ──
let injectReady = false;
let teamDomain = null;

// ── Hide Slack nav (persistent preference, default on) ──
const _navHideStyle = document.createElement('style');
_navHideStyle.textContent = `
  .p-tab_rail { display: none !important; }
  .p-client_workspace__tabpanel:not([aria-label="Search"]) > .enabled-managed-focus-container:first-child {
    visibility: hidden !important;
    width: 0 !important;
    min-width: 0 !important;
    overflow: hidden !important;
  }
  .p-client_workspace__tabpanel:not([aria-label="Search"]) { grid-template-columns: 0px auto !important; }
  .p-client_workspace__tabpanel:has(.p-view_contents--secondary):has(.p-view_contents--primary) {
    grid-template-columns: 0px auto auto !important;
    grid-template-areas: "p-view_contents--sidebar p-view_contents--primary p-view_contents--secondary" !important;
  }
  /* Narrow window: Slack drops primary, only sidebar + secondary remain */
  .p-client_workspace__tabpanel:has(.p-view_contents--secondary):not(:has(.p-view_contents--primary)) {
    grid-template-columns: 0px auto !important;
  }
  /* Pull the compose button out of the hidden sidebar */
  button[data-qa="composer_button"] {
    visibility: visible !important;
    position: fixed !important;
    top: 2px !important;
    left: 100px !important;
    z-index: 999 !important;
  }
`;
function hideSlackNav() { if (!_navHideStyle.parentNode) document.head.appendChild(_navHideStyle); }
function showSlackNav() { _navHideStyle.remove(); }

// Apply on load based on stored preference (default: true)
chrome.storage.local.get(['fslackHideNav', 'sidebarTierMap'], (r) => {
  // if (r.fslackHideNav !== false) hideSlackNav();
  // Sync tier map to localStorage for inject.js
  if (r.sidebarTierMap) {
    try { localStorage.setItem('fslackTierMap', JSON.stringify(r.sidebarTierMap)); } catch {}
  }
});
// Listen for live toggle changes from the side panel
chrome.storage.onChanged.addListener((changes) => {
  if ('fslackHideNav' in changes) {
    changes.fslackHideNav.newValue === false ? showSlackNav() : hideSlackNav();
  }
  // Sync tier map from chrome.storage → localStorage for inject.js
  if ('sidebarTierMap' in changes) {
    try {
      localStorage.setItem('fslackTierMap', JSON.stringify(changes.sidebarTierMap.newValue));
      // Clear cached sections so next fetch uses new mapping
      localStorage.removeItem('fslackSidebarSections');
    } catch {}
  }
});

// ── Injected buttons in Slack's top nav ──
function injectNavButtons() {
  if (document.getElementById('fslack-open-btn')) return;

  // Nav toggle button — top left corner (inside the native UI spacer)
  const spacer = document.querySelector('.p-ia4_top_nav__native_ui_spacer');
  if (spacer && !document.getElementById('fslack-nav-toggle')) {
    const toggle = document.createElement('button');
    toggle.id = 'fslack-nav-toggle';
    toggle.title = 'Toggle Slack sidebar';
    function updateToggleLabel(hidden) {
      toggle.textContent = hidden ? '☰ Show Nav' : '☰ Hide Nav';
      toggle.classList.toggle('nav-hidden', hidden);
    }
    chrome.storage.local.get('fslackHideNav', (r) => {
      updateToggleLabel(r.fslackHideNav !== false);
    });
    toggle.addEventListener('click', () => {
      chrome.storage.local.get('fslackHideNav', (r) => {
        const newVal = r.fslackHideNav === false;
        chrome.storage.local.set({ fslackHideNav: newVal });
        updateToggleLabel(newVal);
      });
    });
    spacer.style.display = 'flex';
    spacer.style.alignItems = 'center';
    spacer.style.paddingLeft = '8px';
    spacer.style.boxSizing = 'border-box';
    spacer.appendChild(toggle);
  }

}

// Inject buttons once Slack DOM is ready
const _btnObserver = new MutationObserver(() => {
  if (document.querySelector('.p-ia4_top_nav')) {
    injectNavButtons();
    _btnObserver.disconnect();
  }
});
_btnObserver.observe(document.body, { childList: true, subtree: true });
injectNavButtons();

// Styles for injected buttons
const _flackBtnStyle = document.createElement('style');
_flackBtnStyle.textContent = `
  #fslack-nav-toggle {
    height: 26px;
    padding: 0 8px;
    border: 1.5px solid rgba(0,0,0,0.4);
    border-radius: 6px;
    background: transparent;
    color: rgba(0,0,0,0.6);
    font-size: 12px;
    font-weight: 600;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 4px;
    white-space: nowrap;
  }
  #fslack-nav-toggle:hover { background: rgba(0,0,0,0.06); }
  @media (prefers-color-scheme: dark) {
    #fslack-nav-toggle {
      border-color: rgba(255,255,255,0.4);
      color: rgba(255,255,255,0.6);
    }
    #fslack-nav-toggle:hover { background: rgba(255,255,255,0.1); }
  }
`;
document.head.appendChild(_flackBtnStyle);

// ── Keyboard shortcut: Cmd+Shift+. to toggle Slack nav ──
document.addEventListener('keydown', (e) => {
  if (e.metaKey && e.shiftKey && (e.key === '.' || e.key === '>' || e.code === 'Period')) {
    e.preventDefault();
    e.stopImmediatePropagation();
    chrome.storage.local.get('fslackHideNav', (r) => {
      const newVal = r.fslackHideNav === false;
      chrome.storage.local.set({ fslackHideNav: newVal });
      const toggle = document.getElementById('fslack-nav-toggle');
      if (toggle) {
        toggle.textContent = newVal ? '☰ Show Nav' : '☰ Hide Nav';
        toggle.classList.toggle('nav-hidden', newVal);
      }
    });
  }
}, true);

// ── Relay: background.js / side panel → inject.js (page context) ──
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg?.type?.startsWith(`${FSLACK}:`)) return;
  console.log(`[fslack content] received: ${msg.type}`);

  // sidepanelConnected ping: hide Slack nav and re-emit fslack:ready if inject.js already loaded
  if (msg.type === `${FSLACK}:sidepanelConnected`) {
    chrome.storage.local.set({ fslackHideNav: true });
    hideSlackNav();
    const toggle = document.getElementById('fslack-nav-toggle');
    if (toggle) { toggle.textContent = '☰ Show Nav'; toggle.classList.add('nav-hidden'); }
    if (injectReady) {
      chrome.runtime.sendMessage({ type: `${FSLACK}:ready`, teamDomain }).catch(() => {});
    }
    return;
  }

  

  // Forward all other fslack:* messages to inject.js via postMessage
  window.postMessage(msg, '*');
});

// ── Relay: inject.js (page context) → background.js → side panel ──
window.addEventListener('message', (event) => {
  if (event.source !== window) return;
  const msg = event.data;
  if (!msg?.type?.startsWith(`${FSLACK}:`)) return;

  // Track inject.js ready state + cache workspace→team mapping for redirect.js
  if (msg.type === `${FSLACK}:ready`) {
    console.log('[fslack content] inject.js ready, teamDomain:', msg.teamDomain);
    injectReady = true;
    if (msg.teamDomain) teamDomain = msg.teamDomain;

    // Extract team ID from app.slack.com URL path: /client/T.../...
    const teamMatch = window.location.pathname.match(/\/client\/(T[A-Z0-9]+)/);
    if (teamMatch && msg.teamDomain) {
      chrome.storage.local.get('workspaceTeamMap', (r) => {
        const map = r.workspaceTeamMap || {};
        map[msg.teamDomain] = teamMatch[1];
        chrome.storage.local.set({ workspaceTeamMap: map });
      });
    }
  }

  // Forward to background.js (which relays to side panel)
  try {
    chrome.runtime.sendMessage(msg).catch(() => {});
  } catch {}
});
